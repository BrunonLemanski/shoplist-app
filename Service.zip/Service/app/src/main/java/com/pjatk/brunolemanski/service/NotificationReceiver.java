package com.pjatk.brunolemanski.service;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class NotificationReceiver extends BroadcastReceiver {

    public static String SHOP_ACTION_PRODUCT = "com.pjatk.brunolemanski.NEW_PRODUCT";
    public static String receivedId = "";

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.i(" -------- ----- ------ ", "Run Receive " + intent.getAction());

        if(SHOP_ACTION_PRODUCT.equals(intent.getAction())) {
            Intent background = new Intent(context, BackgroundService.class);
            receivedId = intent.getStringExtra("com.pjatk.brunolemanski.NEW_PRODUCT.ID");

            context.startService(background);
        }
    }
}
