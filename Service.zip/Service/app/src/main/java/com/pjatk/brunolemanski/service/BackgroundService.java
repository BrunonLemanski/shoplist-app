package com.pjatk.brunolemanski.service;

import android.app.IntentService;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.util.Log;

import static com.pjatk.brunolemanski.service.App.CHANNEL_1_ID;
import static com.pjatk.brunolemanski.service.App.CHANNEL_1_NAME;
import static com.pjatk.brunolemanski.service.NotificationReceiver.receivedId;

public class BackgroundService extends IntentService {

    public static String SHOP_INTENT = "com.pjatk.brunolemanski.shoplist";
    private NotificationManagerCompat notificationManager;

    public BackgroundService() {
        super("Service");
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        sendOnChannel1();
    }

    @Override
    public void onCreate() {
        super.onCreate();

        notificationManager = NotificationManagerCompat.from(this);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }


    private void sendOnChannel1() {
        Context context = getApplicationContext();
        PackageManager pm = context.getPackageManager();
        Intent LaunchIntent = null;

        try{
            if(pm != null) {
                ApplicationInfo app = context.getPackageManager().getApplicationInfo(SHOP_INTENT, 0);
                LaunchIntent = pm.getLaunchIntentForPackage(SHOP_INTENT);
            }

        }catch (PackageManager.NameNotFoundException e ) {
            e.printStackTrace();
        }

        ComponentName componentName = new ComponentName("com.pjatk.brunolemanski.shoplist", "com.pjatk.brunolemanski.shoplist.EditActivity");
        //Intent intent = LaunchIntent;
        Intent intent = new Intent();
        intent.setComponent(componentName);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, 0);

        Log.i("------- importowane id: ", receivedId);

        Notification notification = new NotificationCompat.Builder(this, CHANNEL_1_ID)
                .setSmallIcon(R.drawable.info_icon)
                .setContentTitle(CHANNEL_1_NAME)
                .setContentText("New product has been added to database.")
                .setContentIntent(pendingIntent)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .build();

        notification.flags = Notification.FLAG_AUTO_CANCEL;
        notificationManager.notify(1, notification);
    }
}
